declare interface Window {
    devToolsExtension: Function;
    __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: Function;
}

declare interface Function {
    resource: string;
    defaultProps: string;
}
