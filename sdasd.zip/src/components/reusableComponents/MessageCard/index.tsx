import * as React from 'react';

export interface IMessageCardProps {
}

export class MessageCard extends React.Component<IMessageCardProps, {}> {
    constructor() {
        super();
    }

    render() {
        return (
            
        )
    }
}