export interface ICA {
    demo: string;
}
