export function demoReducer(state = {}, action) {
    switch (action.type) {
        case 'DEMO':
            return state;

        default:
            return state;
    }
}
